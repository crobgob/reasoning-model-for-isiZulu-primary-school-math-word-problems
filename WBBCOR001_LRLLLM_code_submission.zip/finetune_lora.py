#Script that performs supervised fine-tuning of Qwen2.5-Math-7B using LoRA on GSM8K dataset with chain-of-thought answers
#Corey Webb BSc Hons 2025, UCT



import pandas as pd
import torch
from torch.utils.data import Dataset, random_split
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    default_data_collator,
)
from peft import LoraConfig, get_peft_model
import os
import wandb

#GO OVER ALL OF THESE BEFORE TRAINING
BASE_MODEL = "Qwen/Qwen2.5-Math-7B"  # Pretrained base model
dataset = "GSM8K_Zulu.parquet" #Our translattion of the GSM8K dataset
job_name = "finetune_QZAZ"



#wandb logging
# wandb.init(project=f"{job_name}", name=f"{job_name}")

# Load and randomise dataset from Parquet just there is structure in the dataset.
df = pd.read_parquet(dataset).sample(frac=1.0, random_state=42).reset_index(drop=True)

# Format each row as a string: "Q: question\nA: chain-of-thought" - similar to Qwen2.5-Math-papera
formatted_texts = [f"Q: {q}\nA: {cot}" for q, cot in zip(df["question"], df["CoT"])]

# Load tokenizer and model
model_name = BASE_MODEL
tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=True)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

try:
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=torch.float16,
        device_map="auto"
    )
except Exception as e:
    print(f"Model loading failed: {e}")
    import traceback
    traceback.print_exc()
    exit(1)

model.gradient_checkpointing_enable()
model.config.use_cache = False

# Configure LoRA
peft_config = LoraConfig(
    r=32, # Retains pretty much all performance of full fine-tuning
    lora_alpha=64,
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM",
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
)
model = get_peft_model(model, peft_config)

# Define a PyTorch-compatible dataset
class QADataset(Dataset):
    def __init__(self, texts, tokenizer, max_length=512):
        self.texts = texts
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        text = self.texts[idx]
        tokens = self.tokenizer(
            text, 
            truncation=True, 
            max_length=self.max_length, 
            padding= "max_length", # Padds to max length for batching - not sure of other ways to do this
            return_tensors="pt"
        )
        input_ids = tokens["input_ids"].squeeze()
        attention_mask = tokens["attention_mask"].squeeze()
        
        # Create labels (same as input_ids for causal LM)
        labels = input_ids.clone()
        
        # Mask the prompt part
        prompt_part = text.split("A:")[0] + "A: "
        prompt_tokens = self.tokenizer(prompt_part, add_special_tokens=False)["input_ids"]
        prompt_len = min(len(prompt_tokens), len(labels))
        labels[:prompt_len] = -100
        
        return {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
            "labels": labels
        }

# Create dataset and split into 80% train, 20% validation
full_dataset = QADataset(formatted_texts, tokenizer)
train_size = int(0.8 * len(full_dataset))
val_size = len(full_dataset) - train_size
train_dataset, eval_dataset = random_split(full_dataset, [train_size, val_size])

# Simple data collator that doesn't do additional processing
from transformers import default_data_collator
data_collator = default_data_collator

# Training configuration
training_args = TrainingArguments(
    output_dir=f"output/{job_name}",
    overwrite_output_dir=True,
    num_train_epochs=10,
    per_device_train_batch_size=16,  # maybe increase
    gradient_accumulation_steps=2,
    learning_rate=2e-4,
    fp16=True,
    logging_steps=50,
    eval_strategy="epoch",
    save_strategy="epoch",
    save_total_limit=1,
    load_best_model_at_end=True,
    metric_for_best_model="eval_loss",
    greater_is_better=False,
    report_to="wandb", # Look at comments at top of script - will need to log into wandb and initialise
    gradient_checkpointing=True,
)

# Train using Hugging Face Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,
    data_collator=data_collator,
)

trainer.train()

# Save final LoRA adapter weights
trainer.model.save_pretrained(f"output/{job_name}")